export class VerifyAuthDTO {
  email: string;
  password: string;
}
