export class SingleAuthDto {
    name: string;
    password: string;
    email: string;
    last_name: string;
    admin_id: string;
    test_name: string;
}