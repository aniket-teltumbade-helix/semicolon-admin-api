import { PartialType } from '@nestjs/swagger';
import { CreateAuthDTO } from 'src/auth/dto/create-auth.dto';

export class UpdateTestDto {
    test_name: string;
}
