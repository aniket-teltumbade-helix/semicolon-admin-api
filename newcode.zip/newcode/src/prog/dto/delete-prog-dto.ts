export class DeleleProgDto {
    prog_id: string;
    admin_id: string;
}