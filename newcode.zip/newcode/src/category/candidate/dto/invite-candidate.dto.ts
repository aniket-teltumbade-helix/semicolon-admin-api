export class InviteCandidateDto {
    candidate_id: string;
    test_id: string;
    route: string;
}