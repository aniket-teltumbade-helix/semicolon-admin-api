export class StartTestDto {
    magic_string: string;
}