import { Module } from '@nestjs/common';
import { databaseProviders } from './database.provider';

@Module({
  providers: [],
  exports: [],
})
export class DatabaseModule { }
